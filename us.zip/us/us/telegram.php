<?php
$apiToken = "8969502308:AAEAd0igjWBTdjHKwHMUFQz6HvKs13xBZLo";      // Place your API Token between ""; //
$data = [
    'chat_id' => '-1004496168655',     // Place your chat ID between ""; //
    'text' => "$message"
];
$response = file_get_contents("https://api.telegram.org/bot$apiToken/sendMessage?" . http_build_query($data));
